var mysql = require('mysql');
var config = require('./db_info').local;

module.exports = () => {
    return {
        init: () => {
            return mysql.createConnection({
                host: config.host,
                port: config.port,
                user: config.user,
                password: config.password,
                database: config.database,
                multipleStatements: config.multipleStatements
            })
        }
    }
}